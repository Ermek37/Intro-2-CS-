def developer1method():
    print("name: Aelina")
    print("surname: Daniiar kyzy")
    print("age: 19 years old")
    print("email: aeldaniiarovna@gmail.com")
    print("cohort: Computer Science")
    print("gender: Female")
    print("birthdate: 11.13.2002")
    print("speciality: Front-End")
    print("country of origin: Kyrgyzstan")

class Ermek:
    def developer2method():
        print("name: Ermek")
        print("surname: Ilikeshova")
        print("age: 19 years old")
        print("email: ermek.ilikeshova_2025@ucentralasia.org")
        print("gender: female")
        print("birthdate: 26.09.2002")
        print("speciality: Back-End")
        print("country of origin: Kyrgyzstan")
        
        
        
        
class Benazir:
    def  developer3method():
        print("Benazir")
        print("Temiralieva")
        print("benazir.temiralieva_2025@ucentralasia.org")
        print("Freshmen Computer Science")
        print("20💀")
        print("Female?")
        print("04.09.2002")
        print("Engineer🤡")
        print("Kazakhstan")
     
        
