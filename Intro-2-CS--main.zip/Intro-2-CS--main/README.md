# Intro-2-CS-
Ermek  - leader
Aelina  - member
Benzir - member
